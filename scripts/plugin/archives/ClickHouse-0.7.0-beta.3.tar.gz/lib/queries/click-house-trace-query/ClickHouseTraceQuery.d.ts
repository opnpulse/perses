import type { TraceQueryPlugin } from '@perses-dev/plugin-system';
import type { ClickHouseTraceQuerySpec } from './click-house-trace-query-types';
export declare const ClickHouseTraceQuery: TraceQueryPlugin<ClickHouseTraceQuerySpec>;
//# sourceMappingURL=ClickHouseTraceQuery.d.ts.map