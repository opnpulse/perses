import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { ClickHouseTraceQuerySpec } from './click-house-trace-query-types';
type ClickHouseTraceQueryEditorProps = OptionsEditorProps<ClickHouseTraceQuerySpec>;
export declare function ClickHouseTraceQueryEditor(props: ClickHouseTraceQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=ClickHouseTraceQueryEditor.d.ts.map