import type { TraceQueryPlugin } from '@perses-dev/plugin-system';
import type { ClickHouseTraceQuerySpec } from './click-house-trace-query-types';
export declare const getClickHouseTraceData: TraceQueryPlugin<ClickHouseTraceQuerySpec>['getTraceData'];
//# sourceMappingURL=get-click-house-trace-data.d.ts.map